name = input("Enter your name: ")
age = input("Enter your age: ")
print(f"Hello, {name}! You are {age} years old.")

print("Name: KUNAL DUA")
print("Roll Number: 35614802722")
